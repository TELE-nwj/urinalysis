#include <stdint.h>
uint32_t esp_random(void);
